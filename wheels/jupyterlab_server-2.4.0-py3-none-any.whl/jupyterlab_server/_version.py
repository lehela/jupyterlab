version_info = (2, 4, 0)
__version__ = '.'.join(map(str, version_info[:3])) + ''.join(map(str, version_info[3:]))
